// Welcome Message
window.onload = function () {
    alert("🌱 Welcome to Smart Agriculture Website");
};

// Mobile Menu Toggle
function toggleMenu() {
    var nav = document.getElementById("navLinks");

    if (nav.style.display === "block") {
        nav.style.display = "none";
    } else {
        nav.style.display = "block";
    }
}

// Contact Form Validation
function validateForm() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let message = document.getElementById("message").value;

    if (name === "" || email === "" || message === "") {
        alert("Please fill all fields.");
        return false;
    }

    alert("Message Sent Successfully!");
    return true;
}

// Scroll to Top Button
window.onscroll = function () {
    let btn = document.getElementById("topBtn");

    if (btn) {
        if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
            btn.style.display = "block";
        } else {
            btn.style.display = "none";
        }
    }
};

function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
function showMessage() {
    alert("Welcome! Explore Smart Agriculture Services.");
}